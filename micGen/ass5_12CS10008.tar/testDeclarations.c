// Declaration Phase

double d = 2.3;
int i, w[10];
int a = 4, *p, b;
void func(int i, double d);
char c;

int main () {
	double e = 2.3;
	int f, w[7];
	int r = 4, *q, y;
	char h;
}