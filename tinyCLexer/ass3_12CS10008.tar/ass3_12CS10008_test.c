/********************************
**** The best test file ever ****
********************************/
int main () { // ass3_12CS10008_test.c
  int x,i=1;
  float z67=10.24;
  char c[] = "Hello";
  char y2b45dg = 'd';
  for (i=1;i<10;i++) {
    if(z67<20.48e-13) {
      printf ("%s",c);
    }
  }
}